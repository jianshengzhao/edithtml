<template>
  <div id="board">
    
  </div>
</template>

<script>
import $ from 'jquery'
export default {
  name: 'Canvas',
  data () {
    return {}
  },
  created: function () {
    let self = this
    self.$nextTick(function () {
    })      
  },
  methods: { 
  }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >

 
</style>
