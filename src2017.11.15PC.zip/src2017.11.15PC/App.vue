<template>
  <div id="app" unselectable="on" onselectstart="return false;">
  <!-- top main tool -->
    <div class="top" unselectable="on" onselectstart="return false;">
      <div class="t_left">
        <div class="tl_li" @click="settingEvent">
          <i class="iconfont mb icon-cog " title="设置"></i>
          <span>页面设置</span>
        </div>
        <div class="tl_li" @click="saveEvent">
          <i class="iconfont icon-save" title="保存"></i>
          <span>保存</span>
        </div>
        <div class="tl_li" @click="previewEvent" title="预览">
          <i class="iconfont icon-preview"></i>
          <span>预览</span>
        </div>
       <!--  <div class="tl_li" title="量尺">
          <i class="iconfont icon-scale"></i>
          <span>量尺</span>
        </div> -->
        <div class="tl_li tl_li_on gridli" @click="gridHangle" title="格线">
          <i class="iconfont icon-gridlines"></i>
          <span>格线</span>
        </div>
        <div class="tl_li tl_mod tl_li_Disable" >
          <i class="iconfont icon-align-left"></i>
          <div class="doll"></div>
          <!-- <span>对齐</span> -->
          <ul class="toolbar">
            <li @click="topAlignEvent"><i class="iconfont icon-align-up"></i>上对齐</li>
            <li @click="bottomAlignEvent"><i class="iconfont icon-align-down"></i>下对齐</li>
            <li @click="leftAlignEvent"><i class="iconfont icon-align-left"></i>左对齐</li>
            <li @click="rightAlignEvent"><i class="iconfont icon-align-right"></i>右对齐</li>
            <li @click="centerAlignEvent"><i class="iconfont icon-align-center"></i>水平居中</li>
            <li @click="middleAlignEvent"><i class="iconfont icon-align-middle"></i>垂直居中</li>
          </ul>
        </div>
        <div class="tl_li tl_mod tl_li_Disable" >
          <i class="iconfont icon-layer"></i>
          <div class="doll"></div>
          <!-- <span>图层</span> -->
          <ul class="toolbar">
            <li @click="topFloorEvent"><i class="iconfont icon-layer-top"></i>置于顶层</li>
            <li @click="bottomFloorEvent"><i class="iconfont icon-layer-bottom"></i>置于底层</li>
            <li @click="upFloorEvent"><i class="iconfont icon-layer-up"></i>上移一层</li>
            <li @click="downFloorEvent"><i class="iconfont icon-layer-down"></i>下移一层</li>
          </ul>
        </div>
        <div class="tl_li tl_mod tl_li_Disable" >
          <i class="iconfont icon-copy"></i>
          <div class="doll"></div>
          <!-- <span>操作</span> -->
          <ul class="toolbar" >
            <li @click="shearEvent" :class="onlybloo?'':'tl_li_Disable'"><i class="iconfont icon-shear"></i>剪切</li>
            <li @click="copyEvent" :class="onlybloo?'':'tl_li_Disable'"><i class="iconfont icon-copy"></i>复制</li>
            <li @click="pasteEvent" :class="clipboard?'':'tl_li_Disable'"><i class="iconfont icon-paste"></i>粘贴</li>
            <li @click="deleteEvent" ><i class="iconfont icon-delete"></i>删除</li>
          </ul>
        </div>
      </div>
      <!-- module attribute -->
     <!--  <div class="toolBox"> -->
        <div class="property " >
          <label for="" class="leftBorder">Z :</label>
          <el-input v-model="inp_z" type='number' :disabled='disabled' min='0' max='99' @change='changeInpZ' ></el-input>
        </div>
        <div class="property" >
          <label for="">X :</label>
          <el-input v-model="inp_x" type='number' :disabled='disabled' min='0' @change='changeInpX' ></el-input>
        </div>
        <div class="property">
          <label for="">Y :</label>
          <el-input v-model="inp_y" type='number' :disabled='disabled' min='0' @change='changeInpY' ></el-input>
        </div>
        <div class="property">
          <label for="">宽 :</label>
          <el-input v-model="inp_w" type='number' :disabled='disabled' min='0' @change='changeInpW'></el-input>
        </div>
        <div class="property">
          <label for="">高 :</label>
          <el-input v-model="inp_h" type='number' :disabled='disabled' min='0' @change='changeInpH'></el-input>
        </div>      
      <!-- module font -->      
        <div class="property">
          <label for="" class="leftBorder">字号 :</label>
          <el-input v-model="inp_size" type='number' :disabled='disabled' min='12' @change='changeInpSize'></el-input>
        </div>
        <div class="property">
          <label for="">行高 :</label>
          <el-input v-model="inp_line" type='number' :disabled='disabled' min='12' @change='changeInpLine'></el-input>
        </div>
        <div class="property">
          <label for="">字色 :</label>
          <!-- <el-color-picker v-model="color_font" :disabled='disabled' @change='changeColorFont'></el-color-picker> -->
          <colorPicker class="propertycolor" v-model="color_font" :disabled='disabled' @change='changeColorFont'></colorPicker>
        </div>      
      <!-- module background -->     
        <div class="property">
          <label for="" class="leftBorder">背景 :</label>
          <colorPicker class="propertycolor" v-model="color_bg" :disabled='disabled' @change='changeColorBg'></colorPicker>
        </div>     
      <!-- module border -->      
        <div class="property">
          <label for="" class="leftBorder">边框 :</label>
          <div class="border br-mod br-disable">
            <i class="iconfont2 icon-dayin_biankuangshezhi"></i>
            <div class="doll" ></div>
            <ul class="toolbar">
              <el-radio-group v-model="br_width" @change='changeBorderWidth'>
              <li v-for="(item, index) in br_widths">
                <el-radio-button :key="item.value" :label="item.label">
                  <span v-if="item.value == 0" class="borderWidth">none</span>
                  <span v-else class="borderWidth" :style="'border-bottom-width:' + item.label + 'px;border-style: ' + br_style + ';border-color:#333;'">{{item.label}}</span>
                </el-radio-button>
              </li>
              </el-radio-group>
            </ul>
          </div>
          <div class="border br-mod br-disable" :style="br_width=='0'?'cursor:not-allowed':''">
            <i class="iconfont2 icon-biankuangyangshi" ></i>
            <div class="doll" ></div>
            <ul class="toolbar" v-if="br_width!='0'">
              <el-radio-group v-model="br_style" @change='changeBorderStyle'>
              <li v-for="(item, index) in br_styles">
                <el-radio-button :key="item.value" :label="item.label">
                  <span class="borderStyle" :style="'border-width:' + br_width + 'px;border-style: ' + item.label + ';border-color:#333;'"></span>
                </el-radio-button>
              </li>
              </el-radio-group>
            </ul>
          </div>
          <div class="border br-mod br-disable" >
            <i class="iconfont2 icon-biankuangyanse" ></i>
            <div class="doll" ></div>
            <colorPicker class="br_color" v-model="br_color" @change='changeBorderColor' :disabled="br_width==0">
            </colorPicker>
          </div>
        </div>      
      <!-- module opacity -->     
        <div class="property">
          <label for="" class="leftBorder">透明度 :</label>
          <el-input v-model="inp_opacity" type='number' :disabled='disabled' :step="1" :min='0' :max='100' @change='changeOpacity'></el-input>%
        </div>      
      <!-- module shadow -->
        <div class="property" style="margin-left:4px;">
          <label for="" class="leftBorder">阴影 :</label>
          <div class="border br-mod br-disable shadow">
            <i class="iconfont2 icon-yinying"></i>
            <div class="doll"></div>
            <ul class="toolbar">
              <el-checkbox v-model="check_shadow" @change='changeShadow'>阴影</el-checkbox>
              <div>
                <span>厚度：</span>
                <span>x：</span>
                <span>
                  <el-input v-model="inp_weight_x" type='number' :disabled='disabled' :step="1" :min='0' :max='10' @change='changHShadow'></el-input>
                </span>
                <span>y：</span>
                <span>
                  <el-input v-model="inp_weight_y" type='number' :disabled='disabled' :step="1" :min='0' :max='10' @change='changVShadow'></el-input>
                </span>
              </div>
              <div>
                <span>模糊度：</span>
                <span>
                  <el-input v-model="inp_blur" type='number' :disabled='disabled' :step="1" :min='0' :max='10' @change='changBlurShadow'></el-input>
                </span>
                <span>颜色：</span>
                <span class="colorShadow">
                  <colorPicker v-model="bw_color" @change='changColorShadow'></colorPicker>
                </span>
              </div>
            </ul>
          </div>
        </div>      
      <!-- </div> -->
      <!-- module exit -->     
      <div class="t_clean">       
        <div class="tl_li" @click="cleanScreenEvent">
          <i class="icon-clean">×</i>
          <span>清屏</span>
        </div>       
      </div> 
      <div class="t_right">
        <a href="/">
          <div class="tl_li">
            <i class="iconfont icon-exits"></i>
            <span>退出</span>
          </div>
        </a>
      </div> 
    </div> 
  <!-- assembly library -->
    <div class="library" unselectable="on" onselectstart="return false;">
      <!-- <nav class="lib_nav">
        <ol>
          <li class="on"><i class="iconfont icon-cube"></i><span>组件</span></li>
        </ol>
      </nav> -->
      <div class="lib_box">
        <div class="header basichead">基本组件 <i class="el-icon-caret-bottom"></i></div>
        <div class="lib_ol basicBox"></div>
        <div class="header basichead">网校组件 <i class="el-icon-caret-bottom"></i></div>
        <div class="lib_ol onlineBox"></div>
        <!-- <div class="header">正在做。。。 <i class="el-icon-caret-bottom"></i></div>
        <div class="lib_ol todoBox"></div> -->
        <div class="header">敬请期待。。。</div>
      </div>      
    </div>
    <div class="shrink libshrink">
      <i class="el-icon-arrow-left"></i>
    </div>
  <!-- layer      -->
    <div class="layer" unselectable="on" onselectstart="return false;">
      <div class="lib_box">
        <div class="header layerhead">页头 <i class="el-icon-caret-bottom"></i></div>
        <div class="lib_ol elementHead">
          <div class="ele_li" v-for="(item, index) in elementHead" :dataIndex="index"><span>{{item.text}}</span> <span :dataIndex="index" class="deleteLayer" title="删除">×</span></div>
        </div>
        <div class="header layerhead" >主体 <i class="el-icon-caret-bottom"></i></div>
        <div class="lib_ol elementMain">
          <div class="ele_li" v-for="(item, index) in elementMain" :dataIndex="index"><span>{{item.text}}</span> <span :dataIndex="index" class="deleteLayer" title="删除">×</span></div>
        </div>
        <div class="header layerhead">页尾 <i class="el-icon-caret-bottom"></i></div>
        <div class="lib_ol elementTail">
          <div class="ele_li" v-for="(item, index) in elementTail" :dataIndex="index"><span>{{item.text}}</span> <span :dataIndex="index" class="deleteLayer" title="删除">×</span></div>
        </div>       
      </div>
      <div class="shrink shrinkout">
        <i class="el-icon-arrow-left"></i>
      </div>
    </div>
  <!-- editBox    -->
    <div class="editBox" unselectable="on" onselectstart="return false;" style="-moz-user-select:none;padding-right:314px;">
      <div class="space" >
        <div class="scrollcanvas"></div>
        <div class="canvas grid" >
          <div class="c_top">
            <div class="hoverbar" ondragstart="return false">拖动调节公共页头选区高度</div>
          </div>
          <div class="c_body">
          </div>
          <div class="c_foot">
            <div class="hoverbar" ondragstart="return false">拖动调节公共页尾选区高度</div>
          </div>
        </div>
        <div class="row-t line"></div>
        <div class="row-b line"></div> 
        <div class="col-l line"></div>
        <div class="col-r line"></div>
          <!-- 自定义右键菜单 -->
        <ul class="contextmenu">
          <li @click="upFloorEvent" v-if="rightButton"><i class="iconfont icon-layer-up"></i>上移一层</li>
          <li @click="downFloorEvent" v-if="rightButton"><i class="iconfont icon-layer-down"></i>下移一层</li>
          <div class="divider" v-if="rightButton"></div>       
          <li v-if="rightButton"><i class="iconfont icon-align-left"></i>对齐
            <i class="el-icon-caret-bottom"></i>
            <ol>
              <li @click="topAlignEvent" v-if="rightButton"><i class="iconfont icon-align-up"></i>上对齐</li>
              <li @click="bottomAlignEvent" v-if="rightButton"><i class="iconfont icon-align-down"></i>下对齐</li>
              <li @click="leftAlignEvent" v-if="rightButton"><i class="iconfont icon-align-left"></i>左对齐</li>
              <li @click="rightAlignEvent" v-if="rightButton"><i class="iconfont icon-align-right"></i>右对齐</li>
              <li @click="centerAlignEvent" v-if="rightButton"><i class="iconfont icon-align-center"></i>水平居中</li>
              <li @click="middleAlignEvent" v-if="rightButton"><i class="iconfont icon-align-middle"></i>垂直居中</li>
            </ol>
          </li>
          <div class="divider" v-if="rightButton"></div>
          <li @click="shearEvent" :class="onlybloo?'':'tl_li_Disable'" v-if="rightButton"><i class="iconfont icon-shear"></i>剪切</li>
          <li @click="copyEvent" :class="onlybloo?'':'tl_li_Disable'" v-if="rightButton"><i class="iconfont icon-copy"></i>复制</li>
          <li @click="pasteEvent" :class="clipboard?'':'tl_li_Disable'"><i class="iconfont icon-paste"></i>粘贴</li>
          <li @click="deleteEvent" v-if="rightButton"><i class="iconfont icon-delete"></i>删除</li>
        </ul>
      </div>
    <!-- copyBox  选中的组件容器盒子-->
      <div class="copyBox">
        <div class="copyCon">
        </div>
      </div>  
    </div>
  <!-- dialog弹框 -->
    <el-dialog
      title="页面设置"
      :visible.sync="dialogPageSetting"
      size="pageSet" class="dialogSetting">
      <el-tabs v-model="activeSetting" type="card" >
        <el-tab-pane label="页面设置" name="first" >
          <el-row>
            <el-col :span="5" class="tit">背景色</el-col>
            <el-col :span="7">
              <!-- <el-color-picker v-model="bgColorVal"></el-color-picker> -->
              <colorPicker v-model="bgColorVal" ></colorPicker>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="5" class="tit">前景色</el-col>
            <el-col :span="7">
             <!--  <el-color-picker v-model="prospectColorVal" ></el-color-picker> -->
              <colorPicker v-model="prospectColorVal" ></colorPicker>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="5" class="tit">文字链接hover</el-col>
            <el-col :span="7">
              <!-- <el-color-picker v-model="fontHoverColorVal" ></el-color-picker> -->
              <colorPicker v-model="fontHoverColorVal" ></colorPicker>
            </el-col>
          </el-row>         
          <el-row>
            <el-col :span="5" class="tit">页宽</el-col>
            <el-col :span="7">
              <el-input-number v-model="inp_width" :step="100" size="small"></el-input-number>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="5" class="tit">页高</el-col>          
            <el-col :span="7">          
              <el-input-number v-model="inp_height" :step="100" size="small"></el-input-number>
            </el-col>
          </el-row>
        </el-tab-pane>        
        <el-tab-pane label="背景图设置" name="second">
          <el-row>
            <el-col :span="4" class="tit">背景图</el-col>
            <el-col :span="7">
              <el-upload
                class="upload-demo"
                name="upfile"
                action="/uploadv2/image.html"
                :show-file-list="false"
                :on-success="handleBackdropSuccess"
                :before-upload="beforePictureUpload">
                <img v-if="bgImageUrl" :src="bgImageUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </el-col>
            <el-col :span="6">
              <el-button size="small" @click="cleanBgEvent">清除背景图</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="4" class="tit">显示（%）</el-col>
            <el-col :span="10">
              <el-input-number v-model="inp_percent" :step="2" size="small" :min="0" :max="100"></el-input-number>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="4" class="tit">平铺模式</el-col>
            <el-col :span="10">
              <el-select v-model="repeatBgValue" placeholder="请选择">
                <el-option
                  v-for="item in repeatOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="4" class="tit">固定背景</el-col>
            <el-col :span="10">
              <el-select v-model="attachmentBgValue" placeholder="请选择">
                <el-option
                  v-for="item in attachmentOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
        </el-tab-pane>
        <el-tab-pane label="前景图设置" name="third">
          <el-row>
            <el-col :span="4" class="tit">前景图</el-col>
            <el-col :span="7">
              <el-upload
                class="upload-demo"
                name="upfile"
                action="/uploadv2/image.html"
                :show-file-list="false"
                :on-success="handlePredropSuccess"
                :before-upload="beforePictureUpload">
                <img v-if="pgImageUrl" :src="pgImageUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </el-col>
            <el-col :span="6">
              <el-button size="small" @click="cleanPgEvent">清除前景图</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="4" class="tit">显示（%）</el-col>
            <el-col :span="10">
              <el-input-number v-model="inp_pgPercent" :step="2" size="small" :min="0" :max="100"></el-input-number> 
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="4" class="tit">平铺模式</el-col>
            <el-col :span="10">
              <el-select v-model="repeatPgValue" placeholder="请选择">
                <el-option
                  v-for="item in repeatOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="4" class="tit">固定背景</el-col>
            <el-col :span="10">
              <el-select v-model="attachmentPgValue" placeholder="请选择">
                <el-option
                  v-for="item in attachmentOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogPageSetting = false">取 消</el-button>
        <el-button type="primary" @click="dialogPageSettingEvent">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="编辑文本"
      :visible.sync="dialogText"
      size="text">
      <el-row>
        <el-input
          type="textarea"
          autosize
          placeholder="请输入文字"
          v-model="textarea">
        </el-input>
      </el-row>
      <el-row>
        <el-col :span="3" style="text-align: right">链接类型：</el-col>
        <el-col :span="17">
          <el-select v-model="linkType" placeholder="请选择" @change="linkTypeChangeEvent">
            <el-option
              v-for="item in linkTypeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-col>  
      </el-row>
      <el-row v-if="linkType == 'online'">
        <el-col :span="3" style="text-align: right">链接地址：</el-col>
        <el-col :span="17">
          <el-input v-model="inpOnline" placeholder="请输入链接，如：http://ss.ebh.net"></el-input>
        </el-col>
      </el-row>
      <el-row v-if="linkType == 'news'">
        <el-col :span="3" style="text-align: right">链接地址：</el-col>
        <el-col :span="17">
          <el-cascader
            placeholder="请选择资讯"
            :options="selectNewsOptions"
            v-model="selectNews"
            @change="selectNewsChange"
            @active-item-change="handleNewsItemChange">
          </el-cascader>
        </el-col>
      </el-row>
      <el-row v-if="linkType == 'coruse'">
        <el-col :span="3" style="text-align: right">链接地址：</el-col>
        <el-col :span="17">
          <el-cascader
            placeholder="请选择课程"
            :options="selectCoruseOptions"
            v-model="selectCoruse"
            @change="selectCoruseChange"
            @active-item-change="handleCoruseItemChange">
          </el-cascader>
        </el-col>
      </el-row>
      <span slot="footer" class="dialog-footer">        
        <el-button @click="dialogText = false">取 消</el-button>
        <el-button type="primary" @click="dialogTextEvent">确 定</el-button>
      </span>
    </el-dialog>
   <!--  <el-dialog
      title="富文本"
      :visible.sync="dialogEditor"
      size="small" class="ueditor">
      <div ref="ueditor" class='editorC'></div>    
      <span slot="footer" class="dialog-footer">        
        <el-button @click="dialogEditor = false">取 消</el-button>
        <el-button type="primary" @click="dialogEditorEvent">确 定</el-button>
      </span>
    </el-dialog> -->
    <el-dialog
      title="修改图片 ( 点击添加 )"
      :visible.sync="dialogPicture"
      size="picture" class="diaheader diapicture">
      <el-upload
        class="picture-uploader"
        name="upfile"
        action="/uploadv2/image.html"
        :show-file-list="false"
        :on-success="handlePictureSuccess"
        :before-upload="beforePictureUpload">
        <img v-if="pictureUrl" :src="pictureUrl" class="pictureMod">
        <i v-else class="el-icon-plus pageHeader-uploader-icon"></i>
      </el-upload>
      <el-row>
        <el-col :span="3" style="text-align: right">链接类型：</el-col>
        <el-col :span="17">
          <el-select v-model="linkType" placeholder="请选择" @change="linkTypeChangeEvent">
            <el-option
              v-for="item in linkTypeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-col>  
      </el-row>
      <el-row v-if="linkType == 'online'">
        <el-col :span="3" style="text-align: right">链接地址：</el-col>
        <el-col :span="17">
          <el-input v-model="inpOnline" placeholder="请输入链接，如：http://ss.ebh.net"></el-input>
        </el-col>
      </el-row>
      <el-row v-if="linkType == 'news'">
        <el-col :span="3" style="text-align: right">链接地址：</el-col>
        <el-col :span="17">
          <el-cascader
            placeholder="请选择资讯"
            :options="selectNewsOptions"
            v-model="selectNews"
            @change="selectNewsChange"
            @active-item-change="handleNewsItemChange">
          </el-cascader>
        </el-col>
      </el-row>
      <el-row v-if="linkType == 'coruse'">
        <el-col :span="3" style="text-align: right">链接地址：</el-col>
        <el-col :span="17">
          <el-cascader
            placeholder="请选择课程"
            :options="selectCoruseOptions"
            v-model="selectCoruse"
            @change="selectCoruseChange"
            @active-item-change="handleCoruseItemChange">
          </el-cascader>
        </el-col>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogPicture = false">取 消</el-button>
        <el-button type="primary" @click="dialogPictureEvent">确 定</el-button>
      </span>
    </el-dialog>
  <!-- 网校模块   -->    
    <el-dialog
      title="模块动画"
      :visible.sync="dialogscrollanim"
      :close-on-click-modal="false"
      size="scrollanim">
      <el-row>
        <el-col>
          <div @click="editanim()" class="animlist active"><div :class="animtype==''?'animimg active':'animimg'">无<div class="animtip">✔</div></div><p>无效果</p></div>
          <div @click="editanim('fadeIn')" class="animlist"><div :class="animtype=='fadeIn'?'animimg active':'animimg'">
            <img  src="./assets/img/fadeIn_icon.png">
          <div class="animtip">✔</div></div><p>淡入</p></div>
          <div @click="editanim('slideInRight')" class="animlist"><div :class="animtype=='slideInRight'?'animimg active':'animimg'">
            <img  src="./assets/img/slideInRight_icon.png">
          <div class="animtip">✔</div></div><p>飞入</p></div>
          <div @click="editanim('zoomIn')" class="animlist"><div :class="animtype=='zoomIn'?'animimg active':'animimg'">
            <img  src="./assets/img/zoomIn_icon.png">
          <div class="animtip">✔</div></div><p>放大</p></div>
          <div @click="editanim('bounceInRight')" class="animlist"><div :class="animtype=='bounceInRight'?'animimg active':'animimg'">
            <img  src="./assets/img/bounceInRight_icon.png">
          <div class="animtip">✔</div></div><p>跳入</p></div><br>
          <div @click="editanim('flash')" class="animlist"><div :class="animtype=='flash'?'animimg active':'animimg'">
            <img  src="./assets/img/flash_icon.png">
          <div class="animtip">✔</div></div><p>闪现</p></div>
          <div @click="editanim('rotateIn')" class="animlist"><div :class="animtype=='rotateIn'?'animimg active':'animimg'">
            <img src="./assets/img/rotateIn_icon.png">
          <div class="animtip">✔</div></div><p>滚入</p></div>
          <div @click="editanim('flipInY')" class="animlist"><div :class="animtype=='flipInY'?'animimg active':'animimg'">
            <img src="./assets/img/flipInY_icon.png">
          <div class="animtip">✔</div></div><p>翻转</p></div>
          <div @click="editanim('bounceIn')" class="animlist"><div :class="animtype=='bounceIn'?'animimg active':'animimg'">
            <img src="./assets/img/bounceIn_icon.png">
          <div class="animtip">✔</div></div><p>弹性放大</p></div>
          <div @click="editanim('bounceOut')" class="animlist"><div :class="animtype=='bounceOut'?'animimg active':'animimg'">
            <img src="./assets/img/bounceOut_icon.png">
          <div class="animtip">✔</div></div><p>弹性缩小</p></div>
        </el-col>
        
      </el-row>
      <span slot="footer" class="dialog-footer">        
        <el-button @click="dialogscrollanim = false">取 消</el-button>
        <el-button @click="editanimate()" type="primary">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="编辑文本"
      :visible.sync="dialogedittext"
      :close-on-click-modal="false"
      size="edittext">
      <el-row>
        <el-col>
          <el-input v-model="logintext"></el-input>
        </el-col>
        
      </el-row>
      <span slot="footer" class="dialog-footer">        
        <el-button @click="dialogedittext = false">取 消</el-button>
        <el-button @click="editlogintext()" type="primary">确 定</el-button>
      </span>
    </el-dialog>
  <!-- dialog弹框 -->
    <ueditor ref="ueditor" v-model="editEditor"></ueditor>
    <hrefdialog ref="hrefdialogp"></hrefdialog>
    <myimages ref="myimages"></myimages>
    <information ref="information"></information>
    <weather ref="weather"></weather>
    <suspend ref="suspend"></suspend>
    <shape ref="shape"></shape>
    <editbutton ref="editbutton"></editbutton>
    <carousel ref="carousel"></carousel>
    <waiter ref="waiter"></waiter>
    <advert ref="advert"></advert> 
    <course ref="course"></course>
    <player ref="player"></player>
    <addcoursetype ref="addcoursetype"></addcoursetype>      
  <!--<effect ref="effect"></effect> -->
  </div>
</template>
<script>  
  import $ from 'jquery' 
  import configData from '@/data/datahtml.js'
  import tool from '@/data/tool.js'
  import colorPicker from '@/components/colorPicker'
  import ueditor from '@/components/ueditor'
  import hrefdialog from '@/components/hrefdialog'
  import myimages from '@/components/myimages'
  import information from '@/components/information'
  import weather from '@/components/weather'
  import suspend from '@/components/suspend'
  import shape from '@/components/shape'
  import editbutton from '@/components/editbutton'
  import carousel from '@/components/carousel'
  import waiter from '@/components/waiter'
  import advert from '@/components/advert'
  import course from '@/components/course'
  import player from '@/components/player'
  import addcoursetype from '@/components/addcoursetype'
  
  /*import effect from '@/components/effect'*/
  import '@/assets/animate.min.css'
  let config = configData.config.config
  export default { // todo: 本地操作保存
    name: 'app',
    components: {
      colorPicker, 
      ueditor, 
      hrefdialog, 
      myimages,
      information,
      weather, 
      suspend, 
      shape, 
      editbutton, 
      carousel, 
      waiter, 
      advert, 
      course,
      player,
      addcoursetype
    },
    data: function () {
      return {
      // ------------ 工具栏add ----------------------
        onlybloo: true,
        br_width: '0',
        br_widths: [{
          value: '0',
          label: '0'
        },{
          value: '1',
          label: '1'
        },{
          value: '2',
          label: '2'
        },{
          value: '3',
          label: '3'
        },{
          value: '4',
          label: '4'
        },{
          value: '5',
          label: '5'
        }],
        br_style: 'solid',
        br_styles: [{
          value: 'solid',
          label: 'solid'
        },{
          value: 'double',
          label: 'double'
        },{
          value: 'dotted',
          label: 'dotted'
        },{
          value: 'dashed',
          label: 'dashed'
        },{
          value: 'groove',
          label: 'groove'
        },{
          value: 'ridge',
          label: 'ridge'
        },{
          value: 'inset',
          label: 'inset'
        },{
          value: 'outset',
          label: 'outset'
        }
        ],
        br_color: '#ccc',
        inp_opacity: '',        
        check_shadow: false,
        inp_weight_x: '0',
        inp_weight_y: '0',
        inp_blur: '0',
        bw_color: '#ccc',
        editEditor: false,
      //  ---------------登录框文本----------
        logintext :'',
        dialogedittext:false,
      // ------------ 基础组件弹框 -------------------
        dialogscrollanim:false,
        anim:'',
        animtype : 0,
        dialogText: false,
        dialogEditor: false,
        dialogPicture: false,
        dialogButton: false,
        dialogPageSetting: false,
        dialogCarousel: false,
        linkType: 'none',
        linkTypeOptions: [{
          value: 'none',
          label: '无链接'
        }, {
          value: 'online',
          label: '外部链接'
        }, {
          value: 'news',
          label: '资讯链接'
        }, {
          value: 'coruse',
          label: '课程链接'
        }, {
          value: 'login',
          label: '登录弹框'
        }],
        inpOnline: '',
        selectNews: [],
        selectNewsOptions: [],
        selectCoruse: [],
        selectCoruseOptions: [],
      // ------------ 轮播设置 -----------------------
        inputBtnText: '',
        inputBtnHref: '',
        imageUrl: '',
        pictureUrl: '',
        textarea: '',
        activeName: 'first',
        activeNav: 'first',
        carouselData: [{
          imgurl: 'http://static.ebanhui.com/ebh/tpl/newschoolindex/images/slide_banner1.jpg',
          clickurl: ''
        }, {
          imgurl: 'http://static.ebanhui.com/ebh/tpl/newschoolindex/images/slide_banner2.jpg',
          clickurl: ''
        }, {
          imgurl: 'http://static.ebanhui.com/ebh/tpl/newschoolindex/images/slide_banner3.jpg',
          clickurl: ''
        }],
        showTime: 5,
        transitionTime: 0.6,
        showWidth: 1200,
        carouselTit: '轮播图 ( 图片尺寸 1200 * 320 )',
        animStyle: [{
          value: false,
          label: '滚动'
        }, {
          value: true,
          label: '渐显'
        }],
        changeStyle: false,
      // ------------ 工具栏+全局设置+右侧元素图层 ---
        attachmentPgValue: 'scroll',
        attachmentBgValue: 'scroll',
        attachmentOptions: [{
          value: 'scroll',
          label: '滚动'
        },
        {
          value: 'fixed',
          label: '固定'
        }],
        repeatPgValue: 'no-repeat',
        repeatBgValue: 'no-repeat',
        repeatOptions: [{
          value: 'no-repeat',
          label: '不平铺'
        },
        {
          value: 'repeat-y',
          label: 'Y 轴平铺'
        },
        {
          value: 'repeat-x',
          label: 'X 轴平铺'
        },
        {
          value: 'repeat',
          label: '平铺'
        }],
        activeSetting: 'first',
        prospectColorVal: '#fff',
        bgColorVal: '#F5F5F5',
        fontHoverColorVal: '#333',
        bgImageUrl: '',
        pgImageUrl: '',
        inp_percent: '100',
        inp_pgPercent: '100',
        inp_width: 1200,
        inp_height: 1600,
        disabled: true,
        rightButton: false,
        inp_z: '',
        inp_x: '',
        inp_y: '',
        inp_w: '',
        inp_h: '',
        inp_size: '',
        inp_line: '',
        color_font: '#fff',
        color_bg: '#fff',
        moduleElement: '', // 选中的模块全局引用
        moduleElementY:'',
        moduleElementX:'',
        moduleElementR:'',
        moduleElementB:'',
        moduleParentElementHeight: '',      
        clipboard: '',
        original: '',
      // ---------- config --------------
        config: {
          stretchLimit: config.stretchLimit, // 是否开启module拉伸限制
          moveLimit: config.moveLimit // 是否开启module移动限制
        },
        paddingtop: config.paddingtop, // top栏高度
        paddingleft: config.paddingleft, // left栏高度
        postop: config.postop, // editbox  top值
        posleft: config.posleft, // editbox  left值
        fuzzyVal: config.fuzzyVal, // 模糊度
        choiceCon: config.choiceCon,
        preHandleTime: 0,
        elementStorage: {
          c_top: {},
          c_body: {},
          c_foot: {}
        },
        elementHead: [],
        elementMain: [],
        elementTail: [],
        datahtml: configData.config,
      // ------------ common -------------------------
        httpget: function (getParam) { // 封装的异步请求数据
          let self = this
          self.$http.get(window.host + getParam.url, {params: getParam.params}).then((response) => {
            if (getParam.fun !== undefined) {
              getParam.fun(response)
            }
          }).catch(function (response) {
          })
        },
        httppost: function (getParam) { // 封装的异步请求数据
          let self = this
          self.$http.post(window.host + getParam.url, getParam.params, {emulateJSON: true}).then((response) => {
            if (getParam.fun !== undefined) {
              getParam.fun(response)
            }
          }).catch(function (response) {
          })
        },
      // ---------------------------------------------
        tool: tool,
        // { /* 工具箱事件 */
        // // --------------- complete ------------------
        //   // getAlignmentElement: function (self) { // 触碰
        //   //   let parent = self.moduleElement.parent()
        //   //   let arrEle
        //   //   let item = {
        //   //     x: parseInt(self.moduleElement.css('left')),
        //   //     x1: parseInt(self.moduleElement.css('left')) + parseInt(self.moduleElement.css('width')),
        //   //     y: parseInt(self.moduleElement.css('top')),
        //   //     y1: parseInt(self.moduleElement.css('top')) + parseInt(self.moduleElement.css('height'))
        //   //   }
        //   //   let w = parseInt(self.moduleElement.css('width'))
        //   //   let h = parseInt(self.moduleElement.css('height'))
        //   //   switch (parent.attr('class')) {
        //   //     case 'c_top':
        //   //       arrEle = self.elementHead
        //   //       break
        //   //     case 'c_body':
        //   //       arrEle = self.elementMain
        //   //       break
        //   //     case 'c_foot':
        //   //       arrEle = self.elementTail
        //   //       break
        //   //   }
        //   //   $('.touch_module').removeClass('touch_module')
        //   //   let mohubloo = true
        //   //   let line = $('.line')
        //   //   // line.hide()
        //   //   for (let i = 0, len = arrEle.length; i < len; i++) { // todo:校准
        //   //     let ele = arrEle[i]
        //   //     if (ele.x === item.x || ele.x === item.x1 || ele.x1 === item.x || ele.x1 === item.x1 || ele.y === item.y || ele.y === item.y1 || ele.y1 === item.y || ele.y1 === item.y1) {
        //   //       ele.ele.addClass('touch_module')
        //   //     }
        //   //     // if (mohubloo) { // 模糊校准
        //   //     //   self.tool.changeMoveEvents(warp)
        //   //     //   if (Math.abs(ele.x - item.x) < 10){
        //   //     //     self.moduleElement.css('left', Math.abs(ele.x) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.x - item.x1) < 10){
        //   //     //     self.moduleElement.css('left', Math.abs(ele.x - w) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.x1 - item.x) < 10){
        //   //     //     self.moduleElement.css('left', Math.abs(ele.x1) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.x1 - item.x1) < 10){
        //   //     //     self.moduleElement.css('left', Math.abs(ele.x1 - w) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.y - item.y) < 10){
        //   //     //     self.moduleElement.css('top', Math.abs(ele.y) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.y - item.y1) < 10){
        //   //     //     self.moduleElement.css('top', Math.abs(ele.y - h) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.y1 - item.y) < 10){
        //   //     //     self.moduleElement.css('top', Math.abs(ele.y1) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   } else if (Math.abs(ele.y1 - item.y1) < 10){
        //   //     //     self.moduleElement.css('top', Math.abs(ele.y1 - h) + 'px')
        //   //     //     mohubloo = false
        //   //     //     line.show()
        //   //     //   }
        //   //     // }
        //   //     // if(!mohubloo){
        //   //     //   ele.ele.addClass('touch_module')
        //   //     // }
        //   //   }
        //   // },       
        //   // switchModuleEvent: function (type, onthis, self) {
        //   //   let w
        //   //   let getParam
        //   //   let oa
        //   //   switch (type) {
        //   //     case 'picture':
        //   //       self.linkType = 'none'
        //   //       self.inpOnline = ''
        //   //       self.selectNews = []
        //   //       self.selectCoruse = []
        //   //       self.pictureUrl = onthis.find('img').attr('src')
        //   //       // self.dialogPicture = true
		      //   //     self.$refs.myimages.show();
        //   //       oa = onthis.find('.picBox')
        //   //       self.linkType = oa.attr('linkType') || 'none'
        //   //       switch (self.linkType) {
        //   //         case 'online':
        //   //           self.getNewsCategorysData()
        //   //           self.inpOnline = oa.attr('href')
        //   //           break
        //   //         case 'news':
        //   //           self.getNewsCategorysData()
        //   //           self.selectNews = oa.attr('selectNews').split(',')
        //   //           break
        //   //         case 'coruse':
        //   //            self.courseSortData()
        //   //           self.selectCoruse = oa.attr('selectCoruse').split(',')
        //   //           break
        //   //       }
        //   //       break
        //   //     case 'button':
        //   //       self.dialogButton = true
        //   //       self.inputBtnText = onthis.find('a').text()
        //   //       self.inputBtnHref = onthis.find('a').attr('href')
        //   //       break
        //   //     case 'carousel':
        //   //       self.dialogCarousel = true
        //   //       let carouselData = $('.on_module').attr('carouselData')
        //   //       let hs = parseInt($('.screenBox').css('height'))
        //   //       let ws = parseInt($('.screenBox').css('width'))
        //   //       self.carouselTit = '轮播图 ( 图片尺寸 ' + self.showWidth + ' * ' + hs + ')'
        //   //       self.showWidth = ws
        //   //       if (carouselData) {
        //   //         let data = $.parseJSON(carouselData)
        //   //         self.showWidth = data.showWidth
        //   //         self.carouselData = data.carouselData
        //   //         self.showTime = data.showTime
        //   //         self.transitionTime = data.transitionTime
        //   //         self.changeStyle = data.changeStyle
        //   //       }
        //   //       break
        //   //     default:
        //   //       console.log('module')
        //   //       break
        //   //   }
        //   // }
        // },
      // ---------------------------------------------
        getcoursecategorys:function(html){
          let self = this
          self.$http.get(window.host + '/room/design/getcoursecategorys.html', {
            params: {
            }
          }, {emulateJSON: true}).then(function (response) {
            let datas = response.data
            if(datas.code == 0) {
              let packages = datas.data.packages
              let sorts = datas.data.sorts
              let packageshtml = ''
              let sortshtml = ''
              for(var i=0;i<packages.length;i++){
                if(packages[i].pid == 0){
                  packageshtml += '<li class="fl"><a href="/platform.html" class="courselist">'+packages[i].pname+'</a></li>'
                }else{
                  if(packages[i].cur){
                    packageshtml += '<li class="fl"><a href="/platform-1-0-0.html?pid='+packages[i].pid+'" class="courselist onhover">'+packages[i].pname+'</a></li>'
                  }else{
                    packageshtml += '<li class="fl"><a href="/platform-1-0-0.html?pid='+packages[i].pid+'" class="courselist">'+packages[i].pname+'</a></li>'
                  }
                }
              }
              for(var i=0;i<sorts.length;i++){
                if(sorts[i].sid == -1){
                  sortshtml += '<li class="fl"><a href="/platform-1-0-0.html?pid='+sorts[i].pid+'" class="courselist onhover">'+sorts[i].sname+'</a></li>'
                }else{
                  sortshtml += '<li class="fl"><a href="/platform-1-0-0.html?pid='+sorts[i].pid+'&sid='+sorts[i].sid+'" class="courselist">'+sorts[i].sname+'</a></li>'
                }
              }
              html.find('.allson').html(packageshtml)
              html.find('.allsondouble').html(sortshtml)
            }
          }, function (response) {
            console.log(response)
          })
        },
        createmap:function(html){
          let self = this
          var	lng = parseFloat(window.roominfo.lng),
          		lat = parseFloat(window.roominfo.lat),
           		map = new BMap.Map("schoolmap"),
          		point = new BMap.Point(lng, lat),
			  			marker = new BMap.Marker(point),
			  			top_right_navigation = new BMap.NavigationControl({anchor: BMAP_ANCHOR_TOP_LEFT, type: BMAP_NAVIGATION_CONTROL_SMALL});
			  			
			  	map.centerAndZoom(point, 12);  //设置中心点坐标
			  	map.addOverlay(marker);
			  	map.addControl(top_right_navigation); 
			  	map.disableDragging();     
			  	
			  	var sContent = "<h4 style='margin:0 0 5px 0;padding:3px 0;font-size:15px;color:#DD6A22;'>荣安中心</h4>" 
			  	+"<p style='font-size:13px;'>浙江省杭州市江干区城星路188号</p>"
			  	var infoWindow = new BMap.InfoWindow(sContent);
			  	var pointinfo = new BMap.Point(lng, lat+0.01);	
					map.openInfoWindow(infoWindow,pointinfo); //开启信息窗口
        },
        createqr_logo:function(html){
        	let self = this
        	if(html.hasClass("schoolqr")){
        		html.find("img").attr("src",window.roominfo.wechatimg)
        	}else{
        		html.find("img").attr("src",window.roominfo.cface)
        	}
        },
        createintroduce:function(html){
        	let self = this
        	html.find(".picBox").html(window.roominfo.summary)
        }
      }
    },
    created: function () {
      var self = this
      self.$nextTick(function () {
        let canvas = $('.canvas')
        let space = $('.space')
        canvas.css({'left': self.posleft + 'px', 'top': self.postop + 'px'})
        self.inp_width = parseInt(canvas.css('width'))
        self.inp_height = parseInt(canvas.css('height'))
        space.scrollLeft(900)
        let head = $('.c_top')
        let middle = $('.c_body')
        let foot = $('.c_foot')
        if (window.saveParams) {
          let params = window.saveParams
          let pp = params.page
          self.prospectColorVal = pp.pg =='transparent'?null:pp.pg
          self.bgColorVal = pp.bg =='transparent'?null:pp.bg
          self.fontHoverColorVal = pp.fontHover
          self.inp_width = parseInt(pp.width)
          self.inp_height = parseInt(pp.height)
          self.pgImageUrl = pp.pgImage.backgroundImage.split('(')[1].split(')')[0]
          self.inp_pgPercent = pp.pgImage.backgroundSize.split('%')[0]
          self.repeatPgValue = pp.pgImage.backgroundRepeat
          self.attachmentPgValue = pp.pgImage.backgroundAttachment
          self.bgImageUrl = pp.bgImage.backgroundImage.split('(')[1].split(')')[0]
          self.inp_percent = pp.bgImage.backgroundSize.split('%')[0]
          self.repeatBgValue = pp.bgImage.backgroundRepeat
          self.attachmentBgValue = pp.bgImage.backgroundAttachment
          space.css(pp.bgImage)
          space.css('backgroundColor', pp.bg)
          canvas.css(pp.pgImage)
          canvas.css('backgroundColor', pp.pg)
          canvas.css('width', pp.width)
          canvas.css('height', pp.height)
          head.css('height', pp.top)
          foot.css('height', pp.foot)
          canvas.css({'paddingTop': pp.top, 'paddingBottom': pp.foot})
          let module = params.module
          head.html(module.top)
          middle.html(module.body)
          foot.html(module.foot)          
          tool.tool.carryLayerEvent(self, head)
          tool.tool.carryLayerEvent(self, middle)
          tool.tool.carryLayerEvent(self, foot)
          tool.tool.carryLineHeightEvent()
          tool.tool.carryUpdateElementStorageEvent(self, head, head.find('.module'))
          tool.tool.carryUpdateElementStorageEvent(self, middle, middle.find('.module'))
          tool.tool.carryUpdateElementStorageEvent(self, foot, foot.find('.module'))
          // 客服     
          if ($('.waiter').length < 2 && $('.waiter').length > 0) {
            $('.editBox').append('<div class="waiter "><div class="kf-head"></div><div class="kf-top"></div></div>')
            $('.waiter').on('click', function() {
              self.$refs.waiter.show(self, canvas.find('.waiter'))
            })
          } 
        } else {
          let getParam = {
            url: '/aroomv3/roominfo.html',
            params: {},
            fun: function (response) {
              let crid = response.body.data.crid
              window.roominfo = response.body.data
              let getParams = {
                url: '/room/design/getdesign.html',
                params: {crid: crid},
                fun: function (response) {
                  let saveParams = response.body.data                
                  let headHtml = saveParams.head.replace(/[\\]/g, '')
                  let bodyHtml = saveParams.body.replace(/[\\]/g, '')
                  let footHtml = saveParams.foot.replace(/[\\]/g, '')
                  let pp = $.parseJSON(saveParams.settings.replace(/[\\]/g, ''))
                  self.prospectColorVal = pp.pg =='transparent'?null:pp.pg
                  self.bgColorVal = pp.bg =='transparent'?null:pp.bg
                  self.fontHoverColorVal = pp.fontHover||'#333'
                  self.inp_width = parseInt(pp.width)
                  self.inp_height = parseInt(pp.height)
                  self.pgImageUrl = pp.pgImage.backgroundImage.split('(')[1].split(')')[0]
                  self.inp_pgPercent = pp.pgImage.backgroundSize.split('%')[0]
                  self.repeatPgValue = pp.pgImage.backgroundRepeat
                  self.attachmentPgValue = pp.pgImage.backgroundAttachment
                  self.bgImageUrl = pp.bgImage.backgroundImage.split('(')[1].split(')')[0]
                  self.inp_percent = pp.bgImage.backgroundSize.split('%')[0]
                  self.repeatBgValue = pp.bgImage.backgroundRepeat
                  self.attachmentBgValue = pp.bgImage.backgroundAttachment
                  space.css('backgroundColor', pp.bg)
                  space.css(pp.bgImage)
                  canvas.css('backgroundColor', pp.pg)
                  canvas.css(pp.pgImage)
                  canvas.css('width', self.inp_width)
                  canvas.css('height', self.inp_height)
                  head.css('height', pp.top)
                  foot.css('height', pp.foot)
                  canvas.css({'paddingTop': pp.top, 'paddingBottom': pp.foot})
                  head.html(headHtml)
                  middle.html(bodyHtml)
                  foot.html(footHtml)
                  self.moduleElement = $('.on_module')
                  tool.tool.carryLayerEvent(self, head)
                  tool.tool.carryLayerEvent(self, middle)
                  tool.tool.carryLayerEvent(self, foot)
                  tool.tool.carryLineHeightEvent()
                  tool.tool.carryUpdateElementStorageEvent(self, head, head.find('.module'))
                  tool.tool.carryUpdateElementStorageEvent(self, middle, middle.find('.module'))
                  tool.tool.carryUpdateElementStorageEvent(self, foot, foot.find('.module'))
                  if ($('.waiter').length < 2 && $('.waiter').length > 0) {
                    $('.editBox').append('<div class="waiter "><div class="kf-head"></div><div class="kf-top"></div></div>')
                    $('.waiter').on('click', function() {
                      self.$refs.waiter.show(self, canvas.find('.waiter'))
                    })
                  } 
                  tool.tool.topRangeY = parseInt(tool.tool.top.css('height')) + self.paddingtop + self.postop // top选区范围
                  tool.tool.bodyRangeY = parseInt(tool.tool.body.css('height')) + tool.tool.topRangeY // body选区范围
                }
              }
              self.httppost(getParams)
            }
          }
          self.httpget(getParam)
        }
        
        tool.tool.init(self, $)
        let shadow = $('.property .shadow .toolbar')
        let colorbox = shadow.find('.box')
        let $top = $('.top')
        let width
        let moveShadow
        positionshadow()
        $(window).resize(function(event) {
           positionshadow()
        })
        function positionshadow() {
          width = parseInt($top.css('width'))
          if(width < 1845){
            width = parseInt($top.css('width'))   
            if(width < 1558) {             
              shadow.css('left', '0px')
              colorbox.css('left', '0px')
            } else {
              moveShadow = width - 1845             
              if (moveShadow < -212) {
                shadow.css('left', '-212px')
                colorbox.css('left', (moveShadow + 212) + 'px')
              }else{
                shadow.css('left', moveShadow + 'px')
              }
            }     
          }
        }
      })
    },
    methods: {
      cleanScreenEvent: function () {
        let self = this
        self.$confirm('此操作将清除页面为空白页, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let head = $('.c_top')
          let middle = $('.c_body')
          let foot = $('.c_foot')
          head.html('<div class="hoverbar" ondragstart="return false">拖动调节公共页头选区高度</div>')
          middle.html('')
          foot.html('<div class="hoverbar" ondragstart="return false">拖动调节公共页尾选区高度</div>')
          tool.tool.carryLayerEvent(self, head)
          tool.tool.carryLayerEvent(self, middle)
          tool.tool.carryLayerEvent(self, foot)
          tool.tool.carryLineHeightEvent()
          tool.tool.carryUpdateElementStorageEvent(self, head, head.find('.module'))
          tool.tool.carryUpdateElementStorageEvent(self, middle, middle.find('.module'))
          tool.tool.carryUpdateElementStorageEvent(self, foot, foot.find('.module'))
          self.elementStorage.c_top = {}
          self.elementStorage.c_body = {}
          self.elementStorage.c_foot = {}
          self.$message({
            type: 'success',
            message: '清屏成功!'
          });
        }).catch(() => {
          self.$message({
            type: 'info',
            message: '已取消清屏'
          });          
        });
      },
      dialogeditlogin(){
        let self = this
        self.logintext = ''
        let type = $('.on_module input').attr('name')
        switch(type){
          case 'username':
            self.logintext = $('.on_module input').attr('placeholder')
          break
          case 'password':
            self.logintext = $('.on_module input').attr('placeholder')
          break
          case 'Submit':
            self.logintext = $('.on_module input').attr('value')
          break
        }
        self.dialogedittext = true
      },
      editlogintext(){
        let self = this
        let type = $('.on_module input').attr('name')
        switch(type){
          case 'username':
            self.logintext = $('.on_module input').attr('placeholder',self.logintext)
          break
          case 'password':
            self.logintext = $('.on_module input').attr('placeholder',self.logintext)
          break
          case 'Submit':
            self.logintext = $('.on_module input').attr('value',self.logintext)
          break
        }
        self.dialogedittext = false
      },
      dialoganim(){
        let self = this
        let anim  = $('.on_module').attr('data-kui-anim')
        self.anim = anim;
        self.animtype = anim;
        self.dialogscrollanim = true
      },
      editanim(val){
        let self = this;
        let anim = val || ''
        self.animtype = anim;
        self.anim = anim;
        let a = $('.on_module');
        a.addClass('animated '+anim);
        setTimeout(function(){
          a.removeClass(anim);
          a.removeClass('animated');
        }, 1000);
      },
      editanimate(){
        let self = this;
        let a = $('.on_module');
        a.attr('data-kui-anim',self.anim)
        self.dialogscrollanim = false
      },
    // ------------- complete ----------------
      settingEvent: function () { // 页面设置
        let self = this
        self.dialogPageSetting = true
      },
      handleBackdropSuccess: function (res) {
        let self = this
        let showurl = res.data.showurl
        self.bgImageUrl = showurl
      },
      handlePredropSuccess: function (res) {
        let self = this
        let showurl = res.data.showurl
        self.pgImageUrl = showurl
      },
      cleanBgEvent: function () {
        var self = this
        self.bgImageUrl = ''
      },
      cleanPgEvent: function () {
        var self = this
        self.pgImageUrl = ''
      },
      dialogPageSettingEvent: function () { // 页面设置弹框保存
        var self = this
        let space = $('.space')
        let canvas = $('.canvas')
        if (self.bgColorVal) {
          space.css('backgroundColor', self.bgColorVal)
        } else {
          space.css('backgroundColor', 'transparent')
        }
        if (self.prospectColorVal) {
          canvas.css('backgroundColor', self.prospectColorVal)
        } else {
          canvas.css('backgroundColor', 'transparent')
        }
        if(self.bgImageUrl){
          let bgJson = {'backgroundImage': 'url(' + self.bgImageUrl + ')', 'backgroundSize': self.inp_percent + '% auto', 'backgroundRepeat': self.repeatBgValue,'backgroundAttachment': self.attachmentBgValue}
          space.css(bgJson)
        } else {
          space.css('backgroundImage','none')
        }

        if(self.pgImageUrl){
          let pgJson = {'backgroundImage': 'url(' + self.pgImageUrl + ')', 'backgroundSize': self.inp_pgPercent + '% auto', 'backgroundRepeat': self.repeatPgValue,'backgroundAttachment': self.attachmentPgValue}
          canvas.css(pgJson)
        } else {
          canvas.css('backgroundImage','none')
        }      
        if (self.fontHoverColorVal) {
          $('#fontHover').remove()
          $('head').append('<style id="fontHover">body a[href]:hover{color:' + self.fontHoverColorVal + ';}</style>')
        }
        canvas.css('width', self.inp_width)
        canvas.css('height', self.inp_height)
        tool.tool.carryLineHeightEvent()
        self.dialogPageSetting = false
      },
      previewEvent: function () { // 预览
        let self = this
        tool.tool.cleanSignEvent(self)
        $('.setInfo').remove()
        self.$router.push('preview')
        let params = {}
        let headArray = $('.c_top').html()
        let bodyArray = $('.c_body').html()
        let footArray = $('.c_foot').html()
        params = {
          page: {
            pg: self.prospectColorVal?self.prospectColorVal:'transparent',
            bg: self.bgColorVal?self.bgColorVal:'transparent',
            fontHover: self.fontHoverColorVal,
            pgImage: {'backgroundImage': 'url(' + self.pgImageUrl + ')', 'backgroundSize': self.inp_pgPercent + '% auto', 'backgroundRepeat': self.repeatPgValue,'backgroundAttachment': self.attachmentPgValue},
            bgImage: {'backgroundImage': 'url(' + self.bgImageUrl + ')', 'backgroundSize': self.inp_percent + '% auto', 'backgroundRepeat': self.repeatBgValue,'backgroundAttachment': self.attachmentBgValue},
            width: self.inp_width + 'px',
            height: self.inp_height + 'px',
            top: $('.c_top').css('height'),
            body: $('.c_body').css('height'),
            foot: $('.c_foot').css('height')
          },
          module: {
            top: headArray,
            body: bodyArray,
            foot: footArray
          }
        }
        window.saveParams = params
      },
      gridHangle: function (e) { // 格线开关
        let $gridli = $('.gridli')
        let bloo = $gridli.hasClass('tl_li_on')
        let canvas = $('.canvas')
        if (bloo) {
          $gridli.removeClass('tl_li_on')
          canvas.removeClass('grid')
        } else {
          $gridli.addClass('tl_li_on')
          canvas.addClass('grid')
        }
      },
      saveEvent: function () { // 页面保存
        let self = this
        let setting = {
          pg: self.prospectColorVal?self.prospectColorVal:'transparent',
          bg: self.bgColorVal?self.bgColorVal:'transparent',
          fontHover: self.fontHoverColorVal,
          pgImage: {'backgroundImage': 'url(' + self.pgImageUrl + ')', 'backgroundSize': self.inp_pgPercent + '% auto', 'backgroundRepeat': self.repeatPgValue,'backgroundAttachment': self.attachmentPgValue},
          bgImage: {'backgroundImage': 'url(' + self.bgImageUrl + ')', 'backgroundSize': self.inp_percent + '% auto', 'backgroundRepeat': self.repeatBgValue,'backgroundAttachment': self.attachmentBgValue},
          width: self.inp_width + 'px',
          height: self.inp_height + 'px',
          top: $('.c_top').css('height'),
          body: $('.c_body').css('height'),
          foot: $('.c_foot').css('height')
        }
        let strSetting = window.JSON.stringify(setting)
        let headArray = $('.c_top').html()
        let bodyArray = $('.c_body').html()
        if (bodyArray == '') {
          self.$notify({
            title: '警告',
            message: 'body主体内容不能为空',
            type: 'warning'
          })
          return false
        }
        let footArray = $('.c_foot').html()
        let audition = $('.audition ')
        let auditions = ''
        let auditionArr = {}
        for (let i = 0, len = audition.length; i < len; i++) {
          let itemid = audition.eq(i).attr('auditionid')
          if (!auditionArr[itemid]) {
            if (itemid){
              auditions += itemid + ','
              auditionArr[itemid] = true
            }
          }
        }
        auditions = auditions.substring(0, auditions.length - 1)
        let player = $('.player')
        let vedioids = []
        let vedioidObj = {}
        for (let i = 0, len = player.length; i < len; i++) {
          let playerData = $.parseJSON(player.eq(i).attr('playerData')).playerData
          for (let j = 0, jen = playerData.length; j < jen; j++) {
            let cwid = playerData[j].cwid
            if (!vedioidObj[cwid]) {
              vedioids.push(cwid) 
              vedioidObj[cwid] = true
            }
          }
        }       
        let param = {
          url: '/room/design/save.html',
          params: {
            head: headArray,
            foot: footArray,
            body: bodyArray,
            settings: strSetting,
            status: 0,
            auditions: auditions,
            vedioids: vedioids
          },
          fun: function (response) {
            let body = response.body
            let code = body.code
            let msg = body.msg
            if (code === 0) {
              self.$notify({
                title: '成功',
                message: '保存成功',
                type: 'success'
              })
            } else {
              self.$notify({
                title: '警告',
                message: msg,
                type: 'warning'
              })
            }
          }
        }
        self.httppost(param)
      },
    // ------------- 模块属性控制 ------------
      changeInpZ: function (val) { // z-index 定位
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'zIndex', val)
      },
      changeInpX: function (val) { // left 定位
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'left', val)
      },
      changeInpY: function (val) { // top 定位
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'top', val)
      },
      changeInpW: function (val) { // width 宽度
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'width', val)       
      },
      changeInpH: function (val) { // height 高度
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'height', val)       
      },
      changeInpSize: function (val) { // font-size 字体大小
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'fontSize', val) 
      },
      changeInpLine: function (val) { // line-height 行高
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'lineHeight', val)
      },
      changeColorFont: function (val) { // font-color 字体颜色
        var self = this       
        tool.tool.carryModuleOperationEvent(self, 'color', val)
      },
      changeColorBg: function (val) { // background-color 背景颜色
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'backgroundColor', val)
      },
      changeBorderWidth: function (val) { // 边框宽度（粗细）
        var self = this
        let mods = $('.on_module')
        if (mods.length > 1){
          if (parseInt(self.moduleElementY.css('border-left-width'))!== val){
            tool.tool.carryModuleOperationEvent(self, 'borderWidth', val)
          }
        }else if(mods.length!= 0){
          tool.tool.carryModuleOperationEvent(self, 'borderWidth', val)
        }        
      },
      changeBorderStyle: function (val) { // 边框样式
        var self = this
        let mods = $('.on_module')
        if (mods.length > 1){
          if (self.moduleElementY.css('border-left-style')!== val){
            tool.tool.carryModuleOperationEvent(self, 'borderStyle', val)
          }
        }else if(mods.length!= 0){          
          tool.tool.carryModuleOperationEvent(self, 'borderStyle', val)
        }        
      },
      changeBorderColor: function (val) { // 边框颜色
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'borderColor', val)
      },
      changeOpacity: function (val) { // 透明度
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'opacity', val)
      },
      changeShadow: function (val) { // 阴影开关
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'boxShadow', self.check_shadow)        
      },
      changHShadow: function (val) { // 水平偏移阴影
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'boxShadowX', val)        
      },
      changVShadow: function (val) { // 垂直偏移阴影
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'boxShadowY', val)        
      },
      changBlurShadow: function (val) { // 阴影模糊
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'boxShadowBlur', val)       
      },
      changColorShadow: function (val) { // 阴影颜色
        var self = this        
        tool.tool.carryModuleOperationEvent(self, 'boxShadowColor', val)
      },
    // ------------- 模块操作 ----------------
      topAlignEvent: function () { // top 上对齐
        var self = this
        tool.tool.carryModuleOperationEvent(self, 'topAlign')
      },
      bottomAlignEvent: function () { // top 下对齐
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'bottomAlign')
      },
      leftAlignEvent: function () { // left 左对齐
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'leftAlign')
      },
      rightAlignEvent: function () { // left 右对齐
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'rightAlign')
      },
      centerAlignEvent: function () { // left 水平居中
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'centerAlign')
      },
      middleAlignEvent: function () { // top 垂直居中
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'middleAlign')
      },
      topFloorEvent: function () { // 图层置顶
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'topFloor')
      },
      bottomFloorEvent: function () { // 图层置底
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'bottomFloor')
      },
      upFloorEvent: function () { // 图层上移一层
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'upFloor')       
      },
      downFloorEvent: function () { // 图层下移一层
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'downFloor')
      },
      shearEvent: function () { // 剪切
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'shear')
      },
      copyEvent: function () { // 复制
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'copy')
      },
      pasteEvent: function () { // 粘贴
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'paste')
      },
      deleteEvent: function () { // 删除
        let self = this
        tool.tool.carryModuleOperationEvent(self, 'delete')
      },
    // ------------- 基础模块 ----------------
      dialogTextEvent: function () { // 编辑文本窗口
        let self = this
        let a = self.moduleElement.find('a')
        a.text(self.textarea)
        a.attr('linkType', self.linkType)
        switch (self.linkType) {
          case 'none':
            a.removeAttr('href')
            break
          case 'online':
            let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/
            if (reg.test(self.inpOnline)) {
              a.attr('href', self.inpOnline)
            } else {
              self.$notify({
                title: '警告',
                message: '请输入正确完整的跳转链接',
                type: 'warning'
              })
              return
            }
            break
          case 'news':            
            let itemid = self.selectNews[2]
            a.attr('href', '/dyinformation/' + itemid + '.html')
            a.attr('selectNews', self.selectNews)
            break
          case 'coruse':
            let folderid = self.selectCoruse[2]
            a.attr('href', '/courseinfo/' + folderid + '.html')
            a.attr('selectCoruse', self.selectCoruse)
            break
          case 'login':
            a.removeAttr('href')
            self.moduleElement.addClass('loginEvent')
            break
        }
        if (self.linkType !== 'login') {
          self.moduleElement.removeClass('loginEvent')
        }
        self.dialogText = false
      },     
      beforePictureUpload: function (file) {
        let self = this
        if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif') {
          self.$notify({
            title: '警告',
            message: '上传的图片只能是jpg、png或gif格式。',
            type: 'warning',
            offset: 50,
            duration: 4000
          })
          return false
        }
      },
      handlePageHeaderSuccess: function (res, file) {
        let self = this
        let code = res.code
        if (code === 0) {
          self.imageUrl = res.data.showurl
        } else {
          self.$notify({
            title: '警告',
            message: res.msg,
            type: 'warning',
            offset: 50,
            duration: 4000
          })
        }
      },
    // ------------- 图片基础组件 ------------
      handlePictureSuccess: function (res) { // 图片基础组件图片上传成功
        let self = this
        let code = res.code
        if (code === 0) {
          self.pictureUrl = res.data.showurl
        } else {
          self.$notify({
            title: '警告',
            message: res.msg,
            type: 'warning',
            offset: 50,
            duration: 4000
          })
        }
      },
      dialogPictureEvent: function () { // 保存图片
        let self = this
        self.dialogPicture = false
        self.moduleElement.find('img').attr('src', self.pictureUrl)
        let a = self.moduleElement.find('.picBox')
        a.attr('linkType', self.linkType)
        switch (self.linkType) {
          case 'none':
            self.moduleElement.find('.picBox').removeAttr('href')
            break
          case 'online':
            let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/
            if (reg.test(self.inpOnline)) {
              self.moduleElement.find('.picBox').attr('href', self.inpOnline)
            } else {
              self.$notify({
                title: '警告',
                message: '请输入正确完整的跳转链接',
                type: 'warning'
              })
              return
            }
            break
          case 'news':
            let itemid = self.selectNews[2]
            a.attr('href', '/dyinformation/' + itemid + '.html')
            a.attr('selectNews', self.selectNews)
            break
          case 'coruse':
            let folderid = self.selectCoruse[2]
            a.attr('href', '/courseinfo/' + folderid + '.html')
            a.attr('selectCoruse', self.selectCoruse)
            break
          case 'login':
            self.moduleElement.addClass('loginEvent')
            a.removeAttr('href')
            break
        }
        if (self.linkType !== 'login') {
          self.moduleElement.removeClass('loginEvent')
        }
      },
      linkTypeChangeEvent: function (value) {
        let self = this
        switch (value) {
          case 'news':
            self.getNewsCategorysData()
            break
          case 'coruse':
            self.courseSortData()
            break
        }
        // self.selectNewsOptions
        // self.courseSortData()
      },
      selectNewsChange: function () {
      },
      getNewsCategorysData: function () {
        let self = this
        let param = {
          url: '/aroomv3/news/getNewsCategorys.html',
          params: {},
          fun: function (response) {
            let navList = response.body.data
            let obj = []
            for (let i = 0, len = navList.length; i < len; i++) {
              let item = navList[i]
              if (item.code.length < 4 || item.code === 'news') {
                let items = {
                  label: item.name,
                  value: item.code,
                  children: []
                }
                if (item.subnav) {
                  for (let j = 0, jen = item.subnav.length; j < jen; j++) {
                    let jtem = item.subnav[j]
                    let jtems = {
                      label: jtem.name,
                      value: jtem.code,
                      children: []
                    }
                    items.children.push(jtems)
                  }
                }
                items.children.push({label: '其它', value: item.code, children: []})
                obj.push(items)
              }
            }
            self.selectNewsOptions = obj
          }
        }
        self.httpget(param)
      },
      handleNewsItemChange: function (arr) {
        let self = this
        let code = arr[1]
        if (arr.length < 2) {
          return false
        }
        let param = {
          url: '/aroomv3/news.html',
          params: {
            navcode: code,
            pagesize: 100,
            page: 1
          },
          fun: function (response) {
            let newsList = response.body.data
            for (let i = 0, len = self.selectNewsOptions.length; i < len; i++) {
              let item = self.selectNewsOptions[i]
              if (item.value === code || item.value === code.split('s')[0]) {
                for (let j = 0, jen = item.children.length; j < jen; j++) {
                  let jtem = item.children[j]
                  if (jtem.value === code) {
                    let arrFolder = []
                    for (let z = 0, zen = newsList.length; z < zen; z++) {
                      let zitem = newsList[z]
                      arrFolder.push({
                        label: zitem.subject,
                        value: zitem.itemid
                      })
                    }
                    jtem.children = arrFolder
                    break
                  }
                }
                break
              }
            }
          }
        }
        self.httpget(param)
      },
      selectCoruseChange: function () {},
      handleCoruseItemChange: function (arr) {
        let self = this
        let pid = arr[0].split('|')[1]
        let sid = ''
        let csid = ''
        if (arr.length < 2) return false
        if (arr[1].split('|')[0] === 'pid') {
          pid = arr[1].split('|')[1]
          csid = pid
        } else {
          sid = arr[1].split('|')[1]
          csid = sid
        }
        let param = {
          url: '/aroomv3/course/courselist.html',
          params: {
            pid: pid,
            sid: sid,
            pagesize: 100,
            page: 1
          },
          fun: function (response) {
            let courselist = response.body.data.courselist
            console.log(courselist, 11)
            for (let i = 0, len = self.selectCoruseOptions.length; i < len; i++) {
              let item = self.selectCoruseOptions[i]
              if (item.pid === pid) {
                for (let j = 0, jen = item.children.length; j < jen; j++) {
                  let jtem = item.children[j]
                  if (jtem.sid === csid) {
                    let arrFolder = []
                    for (let z = 0, zen = courselist.length; z < zen; z++) {
                      let zitem = courselist[z]
                      if (sid === '' && zitem.sid < 1) {
                        arrFolder.push({
                          label: zitem.foldername,
                          value: zitem.itemid
                        })
                      } else if (sid !== '') {
                        arrFolder.push({
                          label: zitem.foldername,
                          value: zitem.itemid
                        })
                      }
                    }
                    jtem.children = arrFolder
                    break
                  }
                }
                break
              }
            }
            console.log(self.selectCoruseOptions)
          }
        }
        self.httpget(param)
      },
      courseSortData: function () { // 选择课程 cascader
        let self = this
        let param = {
          url: '/aroomv3/course/coursesort.html',
          params: {
            showbysort: 0
          },
          fun: function (response) {
            let arr = response.body.data
            let obj = []
            for (let i = 0, len = arr.length; i < len; i++) {
              let item = arr[i]
              let itemcountP = parseInt(item.itemcount, 10)
              let items = {
                label: item.pname,
                value: 'pid|' + item.pid,
                children: [],
                pid: item.pid
              }
              if (item.sorts) {
                for (let j = 0, jen = item.sorts.length; j < jen; j++) {
                  let jtem = item.sorts[j]
                  itemcountP = itemcountP - parseInt(jtem.itemcount, 10)
                  let jtems = {
                    label: jtem.sname,
                    value: 'sid|' + jtem.sid,
                    children: [],
                    sid: jtem.sid
                  }
                  if (jtem.itemcount > 0) {
                    items.children.push(jtems)
                  }
                }
              }
              if (itemcountP > 0) {
                items.children.push({label: '其它', value: 'pid|' + item.pid, children: [], sid: item.pid})
              }
              if (item.itemcount > 0) {
                obj.push(items)
              }
            }
            self.selectCoruseOptions = obj
          }
        }
        if (self.selectCoruseOptions.length < 1) {
          self.httpget(param)
        }
      }
    }
  }
</script>

<style>
    .el-dialog__header{
      cursor: move;
    }
    .el-dialog--scrollanim{
      width: 510px;
    }
    .leftBorder{
      border-left: 1px solid #888;
      margin-left: 10px;
      padding-left: 10px;
      line-height: 20px;
      height: 20px;
      display: inline-block;
    }
    .picture{
      border-width: 0; 
      border-style: solid;
      border-color: #000;
    }
    .propertycolor{
      width: 22px;
      height: 15px;
    }
    .propertycolor .colorBtn{  
      position: absolute; 
      top:2px;
      left: 0;    
      border:1px solid #666;
      cursor: pointer;
      /*margin:2px;*/
    }
    #app .propertycolor .box.open{
      margin-top: 20px;
    }
    #app .propertycolor .disabled{
      border-color: #ccc;
    }
  /*app*/
    #app {
      position: relative;
      font-family: 'Avenir', Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      height: 100%;
      cursor: default;
    }
    .nodata{
      background:url(assets/img/nodata.png) no-repeat 50%;
      min-width: 300px;
      width: 100%;
      height: 400px;
    }
  /*top*/
    #app .upload-demo{
      height: 105px;
      width: 120px;
    }
    #app .upload-demo .el-upload {
      width: 100%;
      height: 100%;
      line-height: 105px;
      border: 1px solid #bfcbd9;
      border-radius: 4px;
    }
    #app .upload-demo .el-upload img{
      width: 100%;
      height: 100%;
    }
    .top{
      padding-top: 3px;
      padding-left: 10px;
      padding-right: 130px;
      position: relative;    
      min-width: 1024px;
      border-bottom: 1px solid #d9d9d9;
      z-index: 4;
      background-color: #fff;
      letter-spacing: 0;
      float: left;
      width: 100%;
      box-sizing: border-box;
    }
    .top>div{
      height: 28px;
    }
    .t_logo{
      float: left;
      width: 20px; 
    }
    .t_left{
      float: left;
      width: 380px;  
      height: 28px;
    }
    .tl_li{
      position: relative;
      padding: 2px 4px 0 2px;
      border-radius: 2px;
      position: relative;
      display: inline-block;
      height: 24px;
      margin: 2px ;
      cursor: pointer; 
      text-align: center; 
      border:1px solid #fff;  
      box-sizing: border-box;
    }
    .doll{
      position: absolute;
      top: 50%;
      right:-4px;
      margin-top: -2px;
      border: 3px solid transparent;
      border-bottom-color: #cacaca;
      border-left-color: #cacaca;
      transform:rotate(-45deg);
      -ms-transform:rotate(-45deg);
      -moz-transform:rotate(-45deg);
      -webkit-transform:rotate(-45deg);
      -o-transform:rotate(-45deg);
    }
    .tl_li_on{
      background: rgba(0, 0, 0, 0.04);
      border-color:rgba(0,0,0,.1);
    }
    .tl_li_Disable{
      cursor:not-allowed;
    }
    .top .tl_li_Disable span{
      color: #cacaca;
    }
    .top .tl_li_Disable i{
      color: #cacaca;
    }
    .tl_li i{
      float: left;
      font-size: 18px;
      line-height: 18px;
      color:#f55d54;
    }
    .tl_li>span{
      float: left;
      text-indent: 2px;    
      font-size: 12px;
      height: 18px;
      line-height: 18px;
      color: #525e71;
      padding-left: 2px;
    }
    .tl_li:hover .toolbar{
      display: block;
    } 
    .tl_li_Disable:hover .toolbar{
      display: none;
    }
    .toolbar{
      display: none;
      position: absolute;
      left: 0;
      top: 100%;
      min-width: 112px;
      background: #fff;
      box-shadow: 0 2px 8px 0 rgba(0,0,0,.1);
    }
    .toolbar li{
      padding: 10px;
      text-align:left;
      list-style-type: none;
      color: #525e71;
      text-indent:4px;
      letter-spacing: 2px;
    }
    .toolbar li:hover{
      background-color: #f5f5f7;
    }
    .toolbar li i{
      margin-top: -3px;
      margin-right:5px;
      float: left;
    }  
    .toolbar input::-webkit-inner-spin-button{
      display: none;
    }
    #app .t_clean{
      position: absolute;    
      width: 60px;
      height: 28px;
      top: 3px;
      right: 64px;      
    }
    #app .icon-clean{
      background-color: #fff;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      border: 1px solid #f55d54;
      font-size: 18px;
      color: #f55d54;
      line-height: 12px;
    }
    #app .t_right{
      position: absolute;    
      width: 60px;
      height: 28px;
      top: 3px;
      right: 4px;
      text-align: left;
    } 
    .toolbar .el-col{
      height: 36px;
      line-height: 36px;
    }
    .toolbar .el-input__inner{
      height: 30px;
      width: 80px;
      color: #555;
    }
    .dialogSetting .el-row{
      margin:15px 0;
    }
    .dialogSetting .el-col{
      margin-right: 15px;
      line-height: 36px;    
    }
    .dialogSetting .tit{
      text-align: right;
    }
    .getRegion{
      position: absolute;
      z-index: 200;
      background-color: rgba(245, 93, 84, 0.5);
    }
  /*边框*/
    .pick{
      width: 20px;
      height: 20px;
      background-color: #ccc;
    }
    .border, .shadow{
      position: relative;
      display: inline-block;
      width: 38px;     
      cursor:pointer;
      margin-left: 5px; 
      font-size: 14px;
    }
    .border .doll, .shadow .doll{
      right: 8px;
      border-bottom-color: inherit;
      border-left-color:inherit;
    }
    .border:hover .toolbar{
      display: block;
    }
    .br-disable{    
      cursor: not-allowed;
      border-color: #ccc;
    }
    .br-disable i{
      color: #ccc;
    }  
    .br-disable:hover .toolbar{
      display: none;
    }
    .border .toolbar{
      padding: 10px 2px 4px 2px;
    }
    .border .toolbar li{
      padding: 8px;
      text-indent: 0;
    }
    .border .borderWidth{
      margin: 0 auto;
      display: block;
      width: 100px;
      border: 0;
    }
    .border .borderStyle{
      margin: 0 auto;
      display: block;
      width: 100px;
      height: 5px;
    }
    .shadow .toolbar{
      width: 212px;
      padding: 8px;
    }
    .colorShadow{
      position: relative;
    }
    .shadow .toolbar .m-colorPicker {
      top:5px;
      left:5px;
    }

    .shadow .toolbar span{
      display: inline-block;
    }
    .shadow .toolbar .el-input {
      width: 50px;
    }
    .shadow .toolbar .el-input__inner{
      width: 50px;
      text-indent: 0;
    }
    .shadow .toolbar input::-webkit-inner-spin-button {
      display: block;
    }
    .border .el-radio-button .el-radio-button__inner{
      border-radius: 2px;
    }
    #app .border .br_color {
      position: absolute;
      top:0;
      left: 0;
    }
    #app .border .br_color .colorBtn{
      width: 38px;
      height: 20px;
      opacity: 0;
    }
  /*tool*/  
    .tool{
      padding-top: 2px;
      position: relative;
      min-width: 1024px;
      height: 24px;
      border-bottom: 1px solid #d9d9d9;
      background-color: #fff;
      z-index: 3;
      text-align: center;
    }
    .top .toolBox{
      margin-left: -2px;
      margin-top: 4px;
      display: inline-block;
      height: 20px;
      border-left: 1px solid #9c9c9c;
      padding: 0 10px;

    }  
    .property{
      float: left;
      width: auto;    
      height: 20px;
      margin-top: 4px;
      line-height: 20px;
      text-align: left;
    }
    .property .el-input{
      display: inline-block;
      width: 50px;    
    }
    .property input{
      padding: 0;
      height: 20px;
      text-align: center;
      text-indent: 5px;
      border-radius: 0;
      border:0;
      border-bottom: 1px solid #d9d9d9;
      font-size: 12px;
    }
    .property .el-color-picker{
      float: right;
      margin-right:5px;
    }
    .property .el-color-picker__trigger{
      border:0;
      padding: 0 4px;
      height: 20px;
    }
    .property .el-color-picker__icon{
      display: none;
    }
    .property .is-disabled .el-input__inner{
      background-color: #fff;
    }
  /*leftlibrary*/
    .library{
      position: absolute;
      left: 0;
      top: 0;
      padding-top:35px;
      width: 133px;
      height:100%;   
      border-right: 1px solid #d9d9d9;
      background-color: #fff;
      box-sizing: border-box;
      z-index: 2;
      transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }
    .lib_nav{
      position: absolute;
      width: 40px;
      height: 100%;
      background-color: #f8f8f8;
      border-right:1px solid #d9d9d9;
      opacity: 1;
       transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }  
    .lib_nav ol{
      float: right;
      padding-top: 7px;
      width: 37px;
    }
    .lib_nav li{
      width: 37px;
      height: 64px;
      border-top-left-radius:2px; 
      border-bottom-left-radius:2px; 
      text-align: center;
      cursor: pointer;
    }
    .lib_nav li.on{
       background-color: #fff;
       border: 1px solid #d9d9d9;
       border-right: 0;
    }
    .lib_nav i{
      margin-top: 12px;
      font-size: 18px;
      color: #f55d54;
    }
    .lib_nav span{
      display: inline-block;
    }
    .lib_box{
      width: 100%;
      height: 100%;
      color: #7d8695;
      /*padding-left: 48px;*/
      overflow: hidden;
      overflow-y:auto;
      box-sizing: border-box;
    }
    .header{
      float: left;
      width: 132px;
      font-size: 12px;
      color: #7d8695;
      height: 30px;
      line-height: 30px;    
      cursor: pointer;
      text-indent:10px;
    }    
    .header i{
      float: right;
      margin-right:10px;
      margin-top: 10px;
      font-size: 12px;
      color: #7d8695;
    }
    .basichead i{
      width: 13px;
      height: 13px;
      margin-left: 15px;
      margin-top: 8px;
      margin-right: 0;
      line-height: 15px;
      text-indent: 0;
      float: left;
    }
    .layerhead i{
      width: 13px;
      height: 13px;
      margin-right: 15px;
      margin-top: 8px;     
      line-height: 15px;
      text-indent: 0;      
    }
    .closei i{
      transform:rotate(-90deg);
      -ms-transform:rotate(-90deg);   /* IE 9 */
      -moz-transform:rotate(-90deg);  /* Firefox */
      -webkit-transform:rotate(-90deg); /* Safari 和 Chrome */
      -o-transform:rotate(-90deg); 
    }
    .closeiR i{
      width: 13px;
      height: 13px;
      margin-top: 8px;
      transform:rotate(90deg);
      -ms-transform:rotate(90deg);   /* IE 9 */
      -moz-transform:rotate(90deg);  /* Firefox */
      -webkit-transform:rotate(90deg); /* Safari 和 Chrome */
      -o-transform:rotate(90deg); 
    }
    .lib_ol{
      width: 132px;
      overflow: hidden;
      border-bottom: 1px solid #d9d9d9;
      transition: height 400ms ease-in-out;
    }
    .lib_li{
      float: left;
      width: 62px;
      height: 66px;
      text-align: center;
      font-size: 28px;
      color: #525e71;  
    }
    .lib_li i{
      display: inline-block;
      line-height: 26px;
    }
    .lib_li span{
      display: block;
      width:100%;
      font-size: 12px;
    }
    .lib_li:hover{
      background-color: #f5f5f5;
      cursor:pointer;
    }
    .dataHtml{
      display: none;
    }
    .libshrink{
      position: absolute;
      top: 50%;
      left: 133px;
      width: 22px;
      height: 24px;
      background-color: #fff;
      border:1px solid #d9d9d9;
      border-left: 0;
      border-top-right-radius: 12px;
      border-bottom-right-radius: 12px;
      color: #f55d54;
      text-indent: 1px;
      line-height: 24px;
      cursor: pointer;
      z-index: 4;
      transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }
    .libshrink i {
      transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }
    .shrinkout {
      text-indent: 4px;
    }
    .shrinkout i{
      transform: rotate(180deg);
      -ms-transform: rotate(180deg);
      -moz-transform: rotate(180deg);
      -webkit-transform: rotate(180deg); 
      -o-transform: rotate(180deg); 
    }  
    .basic {
      width: 5px;
    }
    .basic .lib_nav {
      display: none;
      opacity: 0;
    }
    .basic .lib_box {
      padding: 0;
      width: 62px;
    }
    .basic .header, .basic .lib_ol {
      display: none;
      opacity: 0;
    }
  /*layer*/
    .layer{
      position:absolute;
      top:0;
      right:0;
      padding-top:35px;
      width: 181px;
      height:100%;
      border-left: 1px solid #d9d9d9;
      background-color: #fff;
      box-sizing: border-box;
      z-index: 3;
      transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }
    .layerHide{
      width: 0;
    }
    .layer .shrink{
      position: absolute;
      top:50%;
      left: -22px;
      width: 22px;
      height: 24px;
      background-color: #fff;
      border:1px solid #d9d9d9;
      border-right: 0;
      border-top-left-radius: 12px;
      border-bottom-left-radius: 12px;
      color: #f55d54;
      text-indent: 1px;
      line-height: 24px;
      cursor: pointer;   
    }
    .layer .shrink i {
      transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }
    .layer .shrinkout {
      text-indent: 6px;
    }
    .layer .shrinkout i{
      transform: rotate(180deg);
      -ms-transform: rotate(180deg);
      -moz-transform: rotate(180deg);
      -webkit-transform: rotate(180deg); 
      -o-transform: rotate(180deg); 
    }
    .layer .lib_box {
      padding: 0;
    }
    .layer .header{
      width: 100%;
      padding-left: 20px;
      box-sizing: border-box;
      background-color: #f8f8f8;
    }
    .layer .lib_ol {
      width: 100%;
      padding-left: 0px;
      text-indent: 20px;
      box-sizing: border-box;
    }
    .layer .lib_ol .ele_li{
      cursor: pointer;
      height: 24px;
      line-height: 24px;
      border-top: 1px solid #eee;
    }
    .layer .lib_ol .ele_li:hover{
      background-color: #eee;
    }
  /*editBox*/    
    #app .module:hover .promptBox{
      display: block;
    }
    .editBox {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      padding-top: 35px;
      margin-left: 133px;
      margin-right: 181px;
      box-sizing:border-box;    
      background-color: #f5f5f5;
      z-index: 2;
      transition: all 400ms;
      -moz-transition: all 400ms; 
      -webkit-transition: all 400ms; 
      -o-transition: all 400ms;
    }
    .space{
      position: relative;
      width: 100%;
      height: 100%;
      overflow:auto;
    }
    .scrollcanvas {
      width: 3600px;
      height: 1px;
    }
    .canvas{
      position:absolute;
      top: 50px;
      left: 50px;
      padding: 400px 0 200px 0;
      margin-bottom: 100px;
      width: 1200px;
      height: 1800px;
      background-color: #fff;
      background-size:10px 10px;
      box-shadow: 0 0 0 1px #d9d9d9;
      box-sizing: border-box;
      /*overflow: hidden;*/
      cursor: default;
    } 
    .grid{
      background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUAQMAAAC3R49OAAAABlBMVEUAAAAnNk6AHRRIAAAAAnRSTlMAsyT7Lw4AAAANSURBVAjXY2hgoCoAACfQAIGM5uSyAAAAAElFTkSuQmCC);    
    }
    .c_top{
      position: absolute;
      top:0;
      left: 0;
      width: 100%;
      height: 400px;
      border-bottom: 1px dashed #d9d9d9;
      box-sizing: border-box;
    }  
    .c_body{
     /* display: none;*/ /*关闭分区*/
      position: relative;
      height: 100%;
    }
    .c_foot{
      /*display: none;*/ /*关闭分区*/
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      height: 200px;
      border-top: 1px dashed #d9d9d9;
      box-sizing: border-box;
    }  
    .hoverbar{
      display: none;
      position: absolute;
      left: 0;
      bottom: -30px;
      width: 100%;
      height:30px; 
      background-color: rgba(245, 93, 84, 0.9);
      font-size: 14px;
      line-height: 30px;
      text-align: center;
      color: #fff;
      cursor: ns-resize;  
      z-index: 99; 
    }
    .c_top:hover .hoverbar{
     display: block;
    }
    .c_foot:hover .hoverbar{
     display: block;
    }
    .on_hoverbar{
      border-top: 1px solid #f55d54;
      border-bottom: 1px solid #f55d54;
    }
    .c_foot .hoverbar{
      top:-30px;
    }
  /*copyBox*/
    .copyBox{
      position: absolute;
      display: block;    
      width: 200px;
      height: 50px;
      background-color: rgba(245,93,84,0.6);
      z-index: 100;
     /* border: 1px dotted #333;*/
    }
    .copyCon{
      display: none;
    }
    .line{
      position: absolute;
      top: 0;
      left: 0;
      width: 3600px;
      height: 100%;
      border:0;
      border-style:dashed;
      border-color: red;
      display: none;
      z-index: 100;
    }
    .row-t{
      height: 0px;
      border-bottom-width: 1px;
    }
    .row-b{
      height: 0px;
      border-top-width: 1px;
    }
    .col-l{
      width: 0px;
      border-right-width: 1px;
    }
    .col-r{
      width: 0px;
      border-left-width: 1px;
    }
  /*module*/
    .editBox .on_module{
      /*border-color: transparent;*/
      box-sizing: border-box;
      cursor: move;
    }
    .editBox .touch_module {
      border-color: #f55d54;
    }
    .supendTools{
      position: absolute;
      top:-45px;
      left: 0px;
      height: 36px;       
      box-sizing: border-box;
      border:1px solid #E4E4E4;
      background-color: #fff;
      white-space: nowrap;
      cursor: default;
    }
    .supendTools li {
      display: inline-block;
      margin-top: 8px;
      padding:0 12px;
      height: 20px;
      line-height: 20px;
      text-align: center;
      font-size: 14px;
      color: #666;
      cursor: pointer;
      vertical-align:top;
      background-position: center;
      background-repeat: no-repeat;
      background-size: 18px;
    }
    .st-left {
      border-right: 1px solid #E4E4E4;
    }
    .st-prospect {
      width: 20px;
      background-image: url(./assets/toolIcon/a.png);
    }
    .st-effects {
      width: 20px;
      background-image: url(./assets/toolIcon/b.png);
    }
    .st-shape {
      width: 20px;
      background-image: url(./assets/toolIcon/c.png);
    }
    .st-animate {
      width: 20px;
      background-image: url(./assets/toolIcon/d.png);
    }
    .st-link {
      width: 20px;
      border-left: 1px solid #E4E4E4;
      background-image: url(./assets/toolIcon/e.png);
    }
    .fuzzybox{
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgb(254, 233, 218);
    }
    .multiBox {
      position: absolute;
      top: 0;
      left: 0;
      border: 1px solid #f55d54;
      width: 100%;
      height: 100%;
      box-sizing:border-box;
      background-color: rgba(245, 93, 84, 0.5);
    }
    .resizeBox{
      position: absolute;
      top: 0;
      left: 0;
      border: 1px solid #f55d54;
      width: 100%;
      height: 100%;
      box-sizing:border-box;
    }
    .resize{
      position: absolute;
      width: 6px;
      height: 6px;
      background-color:#fff;
      border:1px solid #f55d54;
      pointer-events: auto;
      box-sizing: border-box;
      z-index: 100;
    }
    .nw{
      top: -3px;
      left: -3px;
      cursor: nw-resize;
    }
    .w{
      top:50%;
      left: -3px;
      transform:translateY(-50%);
      -ms-transform:translateY(-50%);   /* IE 9 */
      -moz-transform:translateY(-50%);  /* Firefox */
      -webkit-transform:translateY(-50%); /* Safari 和 Chrome */
      -o-transform:translateY(-50%);
      cursor: w-resize;
    }
    .sw{
      bottom: -3px;
      left:-3px;
      cursor: sw-resize;
    }
    .n{
      top: -3px;
      left: 50%;
      transform:translateX(-50%);
      -ms-transform:translateX(-50%);   /* IE 9 */
      -moz-transform:translateX(-50%);  /* Firefox */
      -webkit-transform:translateX(-50%); /* Safari 和 Chrome */
      -o-transform:translateX(-50%);
      cursor: n-resize;
    }
    .ne{
      top: -3px;
      right: -3px;
      cursor: ne-resize;
    }
    .e{
      top:50%;
      right:-3px;
      transform:translateY(-50%);
      -ms-transform:translateY(-50%);   /* IE 9 */
      -moz-transform:translateY(-50%);  /* Firefox */
      -webkit-transform:translateY(-50%); /* Safari 和 Chrome */
      -o-transform:translateY(-50%);
      cursor: e-resize; 
    }
    .se{
      bottom: -3px;
      right:-3px;
      cursor: se-resize;
    }
    .s{
      bottom: -3px;
      left:50%;
      transform:translateX(-50%);
      -ms-transform:translateX(-50%);   /* IE 9 */
      -moz-transform:translateX(-50%);  /* Firefox */
      -webkit-transform:translateX(-50%); /* Safari 和 Chrome */
      -o-transform:translateX(-50%);
      cursor: s-resize;
    }
  /*contextmenu*/
    .contextmenu{
      position: absolute;
      top:81px;
      left:181px;
      width: 130px;
      background-color: #fefefe;
      padding: 3px 0;
      text-align: left;
      text-indent: 16px;
      box-shadow: 0 2px 8px 0 rgba(0,0,0,.1);
      z-index: 101;
    }
    .contextmenu li{
      position: relative;
      padding:2px;
      height: 26px;
      line-height: 26px;
      color: #525e71;
      cursor: pointer;
    }
    .contextmenu li:hover{
      background-color: #E2E2E3;
    }
    .contextmenu li.tl_li_Disable{
      color: #cacaca;
      cursor: not-allowed;
    }
    .contextmenu li i {
      float: left;
      margin-top: 3px;
      margin-left: 8px;
      color: #f55d54;
      font-size: 18px;
      text-indent: 4px;
    }  
    .contextmenu li i.el-icon-caret-bottom{
      float: right;
      margin: 7px;
      font-size: 12px;
      color: #cacaca;
    } 
    .contextmenu li:hover i.el-icon-caret-bottom{
       transform: rotate(-90deg);
      -ms-transform: rotate(-90deg);
      -moz-transform: rotate(-90deg);
      -webkit-transform: rotate(-90deg); 
      -o-transform: rotate(-90deg); 
      margin-right: 3px;
    }
     .contextmenu li ol{
      position:absolute;
      top:0;
      left:100%;
      display: none;
      width: 130px;
      background: #fff;
      box-shadow: 0 2px 8px 0 rgba(0,0,0,.1);
    }
    .contextmenu li:hover ol{
      display: block;
    }
    .contextmenu li.tl_li_Disable i {
      color: #cacaca;
    }
    .contextmenu .divider{
      margin: 3px 0;
      border-bottom: 1px solid #e5e5e5;
    }
  /*editor*/
    .editorC{
      margin: 0 auto;
      min-height: 400px 
    }
    .el-dialog__footer {
      padding: 10px 10px 15px;
    }
  /*pageHeader-uploader*/
    .el-dialog--text{
      width: 600px;
    }
    .el-dialog--text .el-row{
      margin-bottom: 20px;
    }
    .el-dialog--text .el-col{
      height: 36px;
      line-height: 36px;
    }
    .el-dialog--pageSet{
      width: 500px;
    }
    .el-dialog--pageSet .el-tabs__content{
      overflow: visible;
    }
    .el-dialog--pageSet .m-colorPicker .box{
      z-index: 99;
    }
    #app .el-dialog--pageSet .m-colorPicker .colorBtn{
      width: 30px;
      height: 30px;
      border:1px solid #c4c4c4;
    }
    .pageHeader-uploader .el-upload {
      width: 100%;
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    .pageHeader-uploader .el-upload:hover {
      border-color: #20a0ff;
    }
    .pageHeader-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;
    }
    .pageHeaderImg {
      width: 100%;
      height: auto;
      display: block;
    }
  /*carousel*/
  
  /*picture*/
    .el-dialog--picture{
      width: 750px;
    }
    .picture-uploader .el-upload{
      display: block;
      margin:0 auto; 
      border: 1px dashed #d9d9d9;
    }
    .pictureMod {    
      max-width: 100%;
      display: block;
      margin:0 auto;
    }
    .diapicture .el-col{
      height: 36px;
      line-height: 36px;
    }
    .diapicture .el-row{
      margin-top: 20px;
    }
    .diapicture .el-select{
      width: 320px;
    }
  /*button*/
    .dialogbutton .el-row{
      margin-top: 10px;
    }
    .dialogbutton .el-col-3{
      margin-right: 20px;
      height: 36px;
      text-align: right;
      line-height: 36px;
    }
/* 模块动画 */
  .animlist{
    display: block;
    width: 74px;
    height: 88px;
    text-align: center;
    float: left;
    margin: 24px 10px 0 10px;
    cursor: pointer;
  }
  .animlist .animimg{
    width: 74px;
    height: 64px;
    line-height:64px;
    border: 2px solid #f2f2f2;
    border-radius: 2px;
    position: relative;
  }
  .animlist .animimg:hover{
    border-color: #7fcc78;
  }
  .animlist .animimg .animtip{
    display: none;
    width: 16px;
    height: 16px;
    position: absolute;
    right: 0;
    bottom: 0;
    line-height: 16px;
    background: #7fcc78;
    color: #fff;
  }
  .animlist p{
    line-height: 24px;
  }
  .animlist .active{
    border-color: #7fcc78;
  }
  .animlist .active .animtip{
    display: block;
  }
  /* 模块动画弹窗 */
  .animlist img{
    margin-top: 14px; 
  }
  /* 登录框编辑文本弹窗 */
  .el-dialog--edittext{
    width: 500px;
  }
  .pitchIcon {
    display:none; 
    position: absolute;
    bottom: 0;
    right:0;
    width: 14px;
    height: 14px;
    line-height: 14px;
    color: #fff;
    background-color: #20a0ff;
  }
  .is-active .pitchIcon {
    display: block;
  }
  .ele_li:hover .deleteLayer {
    display: block;
  }
  .deleteLayer{
    display: none;
    float: right;
    font-size: 16px;
    font-weight: 600;
    margin-right: 16px;
  }
</style>
